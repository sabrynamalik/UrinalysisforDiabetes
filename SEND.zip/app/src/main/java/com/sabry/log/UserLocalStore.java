package com.sabry.log;

import android.content.Context;
import android.content.SharedPreferences;

public class UserLocalStore {

    public static final String SP_Name="userDetails";
    SharedPreferences userLocalDatabase;

    public UserLocalStore(Context context) {
        userLocalDatabase = context.getSharedPreferences(SP_Name,0);
    }
 public void storeUserData(User user){
        SharedPreferences.Editor spEditor = userLocalDatabase.edit();
     spEditor.putString("name", user.name);
        spEditor.putString("username", user.username);
     spEditor.putString("password", user.password);
     spEditor.putString("confirm", user.confirm);
     spEditor.commit();

 }
 public User getLoggedInUser() {
     String name = userLocalDatabase.getString("name","");
     String username = userLocalDatabase.getString("username","");
     String password = userLocalDatabase.getString("password","");
     String confirm = userLocalDatabase.getString("confirm","");

        User storedUser= new User(name,username);
        return storedUser;
 }

 public void setUserLoggedIn(boolean loggedIn){
     SharedPreferences.Editor spEditor = userLocalDatabase.edit();
     spEditor.putBoolean("loggedIn", loggedIn);
     spEditor.commit();
 }

 public void clearUserData(){
     SharedPreferences.Editor spEditor = userLocalDatabase.edit();
     spEditor.clear();
     spEditor.commit();
 }
}
